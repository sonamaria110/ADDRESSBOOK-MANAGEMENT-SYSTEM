#include <stdio.h>
#include "contact.h"
#include<string.h>
int validate_name(char*temp_name);
int validate_mobile(char* temp_name,AddressBook* addressbook);
int validate_email(char* temp_email,AddressBook* addressbook);
void sort_contacts(AddressBook*addressbook);
/* Function definitions */
int load_contacts(AddressBook *addressbook)
{
    FILE*fp=fopen("contacts.csv","r");//Opening the file in read mode
    if(fp==NULL)
    {
        printf("File not found!\n");//Checking whether the file is found or not
    }
    else{
    fscanf(fp,"#%d\n",&addressbook->contact_count);//Reading the contact count
    for(int i=0;i<addressbook->contact_count;i++)//Reading the contact details
    {
    fscanf(fp,"%[^,],%[^,],%[^\n]\n",addressbook->contact_details[i].Name,addressbook->contact_details[i].Mobile_number,addressbook->contact_details[i].Mail_ID);
    }
}
    fclose(fp);//Closing the file
   return 0;
}
int create_contact(AddressBook *addressbook)
{
    int i=1;
    //Variables declaration
    char temp_name[20];
    char temp_mobile[11];
    char temp_email[20];
    while(i)
    {
        //Adding the Name
        name_label:
        getchar();
        printf("Enter the Name:");
        scanf("%[^\n]",temp_name);
        if(!validate_name(temp_name))//Validating the Name
        goto name_label;
         
        //Adding Mobile number 
        mobile_label:
        getchar();
        printf("Enter the Mobile Number:");
        scanf("%[^\n]",temp_mobile);
        if(!validate_mobile(temp_mobile,addressbook))//Validating Mobile number
        goto mobile_label;
        
        //Adding email
        email_label:
        getchar();
        printf("Enter the Email ID:");
        scanf("%[^\n]",temp_email);
        
        if(!validate_email(temp_email,addressbook))//Validating email id
        goto email_label;
        //Copying the data to structure
        strcpy(addressbook->contact_details[addressbook->contact_count].Name ,temp_name);
        strcpy(addressbook->contact_details[addressbook->contact_count].Mobile_number ,temp_mobile);
        strcpy(addressbook->contact_details[addressbook->contact_count].Mail_ID ,temp_email);
        printf(GREEN"Contact added successfully!\n"RESET);
        (addressbook->contact_count)++;//Incrementing count
        getchar();
        printf(BLUE"Do you want to add another contact?(1-Yes/0-No)\n"RESET);
        scanf("%d",&i);    
         
    }
    return 0;
}
       




        
        
        
        
    
        
void list_contacts(AddressBook *addressbook)
{
  sort_contacts(addressbook);  
if(addressbook->contact_count ==0)//Checking whether contact count is zero or not
{
    printf(RED"No contacts found!\n"RESET);
}
    else{ // Listing the contact details
int sl = 1;

printf(YELLOW BOLD);
printf("╭───────────────────────────── CONTACT DETAILS ────────────────────────────╮\n");
printf("│ %-5s │ %-20s │ %-15s │ %-24s│\n",
       "SL No", "Name", "Mobile No", "Email ID");
printf("├───────┼──────────────────────┼─────────────────┼─────────────────────────┤\n");

for(int i = 0; i < addressbook->contact_count; i++)
  {
    printf("│ %-5d │ %-20s │ %-15s │ %-24s│\n",
           sl,
           addressbook->contact_details[i].Name,
           addressbook->contact_details[i].Mobile_number,
           addressbook->contact_details[i].Mail_ID);

    
    
        printf("├───────┼──────────────────────┼─────────────────┼─────────────────────────┤\n");
    
    sl++;

    }
        printf("╰───────┴──────────────────────┴─────────────────┴─────────────────────────╯\n");
        printf(RESET);
 }
}


int search_name(AddressBook* addressbook)
{
    //variables declaration
    int flag=0;
    int found = 0;
    int count=0;
    int arr[10];
    int n=0;
    int choice;
    int sl=1;
    //Searching the name of person
    char search_name[20];
    getchar();
        printf("Enter the name of Person:");
        scanf("%[^\n]",search_name);
       for(int i=0;i<addressbook->contact_count;i++)
       {
        if(strcmp(search_name,addressbook->contact_details[i].Name)==0)//Checking whether the name is found or not
        {
            arr[n]=i;//storing the indices to an  integer array if contact is found
            n++;
            count ++;
            
        }
       }
       
       if(count==1)//printing the found contact 
       {
        printf(GREEN"Contact found!\n"RESET);
        printf("+-------+----------------------+-----------------+---------------------------+\n");
         printf("| %-5d | %-20s | %-15s | %-25s |\n",
       sl,
       addressbook->contact_details[arr[0]].Name,
       addressbook->contact_details[arr[0]].Mobile_number,
       addressbook->contact_details[arr[0]].Mail_ID);
      printf("+-------+----------------------+-----------------+---------------------------+\n");
   
        return arr[0];//returning the index of found contact
       }
        else if(count>1)//if multiple contacts with same name is found.Listing them
        {
            printf(BLUE"Multiple contacts are found!Which one do you mean?\n"RESET);//Asking for particular index to display among the contacts
             printf("+-------+----------------------+-----------------+---------------------------+\n");
    printf("| %-5s | %-20s | %-15s | %-25s |\n",
           "SL No", "Name", "Mobile No", "Email ID");
    printf("+-------+----------------------+-----------------+---------------------------+\n");
   
            for(int i=0;i<count;i++)
            {
                printf("| %-5d | %-20s | %-15s | %-2s |\n",
       sl,
       addressbook->contact_details[arr[i]].Name,
       addressbook->contact_details[arr[i]].Mobile_number,
       addressbook->contact_details[arr[i]].Mail_ID);
      printf("+-------+----------------------+-----------------+---------------------------+\n");
      

     sl++;

               
            }
            
            printf("Enter the Index:");
            getchar();
            scanf("%d",&choice);
            printf("+-------+----------------------+-----------------+---------------------------+\n");
             for(int i=0;i<count;i++)//displaying the contact details of selected index
            {
                if(choice-1==i)
                {
               {
                printf("| %-5d | %-20s | %-15s | %-25s |\n",
       choice,
       addressbook->contact_details[arr[i]].Name,
       addressbook->contact_details[arr[i]].Mobile_number,
       addressbook->contact_details[arr[i]].Mail_ID);
      printf("+-------+----------------------+-----------------+---------------------------+\n");
      
        return arr[i];//returning the index of particular contact
               break;
            }
            }


        }
        
    }
       else
       {
        printf(RED"Contact not found!"RESET);//if contact is not found 
        return -1;
       }
}
int search_mobile(AddressBook* addressbook)
{    //variable declaration
    int flag=0;int found=0;
    char search_mob[20];
    getchar();
        printf("Enter the Mobile Number of Person:");//Searching the mobile number
        scanf("%[^\n]",search_mob);
       for(int i=0;i<addressbook->contact_count;i++)
       {
        if(strcmp(search_mob,addressbook->contact_details[i].Mobile_number)==0)//checking whether the mobile number is present or not
        {
            flag=1;
            found=i;
            break;
        }
       }
       if(flag==1)
       {
        printf(GREEN"Contact found!"RESET);//if mobile number is found
        return found;
       }
       else
       {
        printf(RED"Contact not found!"RESET);//if mobile number is not found
        return -1;
       }

}
int search_email(AddressBook* addressbook)//searching by email
{
    //variables declaration
    int flag=0;int found=0;
    char search_email[20];
    getchar();
        printf("Enter the Email ID of Person:");
        scanf("%[^\n]",search_email);
       for(int i=0;i<addressbook->contact_count;i++)//checking whether the email id is found or not
       {
        if(strcmp(search_email,addressbook->contact_details[i].Mail_ID)==0)
        {
            flag=1;
            found=i;
            break;
        }
       }
       if(flag==1)
       {
        printf(GREEN"Contact found!"RESET);//if email id is present
        return found;
       }
       else
       {
        printf(RED"Contact not found!"RESET);//if not found
        return -1;
       }
}
int search_contacts(AddressBook *addressbook)
{  
    label_search:
    printf("Search Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : ");//listing the options to search
    int i=1;
    int  choice;
    scanf("%d",&choice);

   while(i)
   {
    switch(choice){

        case 1:
        search_name(addressbook);
        printf(BLUE"Do you wish to continue search?\n"RESET);
        goto label_search;
        break;
        case 2:
        search_mobile(addressbook);
        printf(BLUE"Do you wish to continue search?\n"RESET);
        goto label_search;
        break;
        case 3:
        search_email(addressbook);
        printf(BLUE"Do you wish to continue search?\n"RESET);
        goto label_search;
        break;
        Default:
        break;
        
    }
    
    return 0;
   }
}

int edit_contact(AddressBook *addressbook)//editing the contact details
{
    //variable declarion
   int i=1;
   int res,choice;
   char temp_name[20];
   char temp_mobile[11];
   char temp_email[20];
   while(i)
   {
    printf("Edit Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : "); /* Providing menu */
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:
        res=search_name(addressbook);
        break;
        case 2:
        res=search_mobile(addressbook);
        break;
        case 3:
        res=search_email(addressbook);
        break;
        case 4:
        return 0;
        default:
        printf(RED"Invalid input!Please enter a valid option!"RESET);
        break;
    }
    if(res==-1)//index returned from the search function
    continue;
    else{
        int opt3;
        printf(BLUE"Which field you want to edit?\n1.Name\n2.Mobile No\n3.Email ID\n4.Edit all\n"RESET);//Asking for the field to edit
        scanf("%d",&opt3);
        switch(opt3)
        {
            case 1:
            //editing the name
             name_label:
             getchar();
             printf("Enter the new name:");
             scanf("%[^\n]",temp_name);
             if(!validate_name(temp_name))
             goto name_label;
             printf(GREEN"Name is edited successfully!\n"RESET);
             strcpy(addressbook->contact_details[res].Name,temp_name);
             //displaying edited contact
             printf(YELLOW"╔══════════════════════════════════════════════════════════════════════════════╗\n"RESET);

             printf(YELLOW"║ %-20s │ %-15s │ %-25s           ║\n"RESET,
             addressbook->contact_details[res].Name,
             addressbook->contact_details[res].Mobile_number,
             addressbook->contact_details[res].Mail_ID);

            printf(YELLOW"╚══════════════════════════════════════════════════════════════════════════════╝\n"RESET);

            break;
            case 2:
            
            mobile_label://editing the mobile number
            getchar();
            printf("Enter the new mobile Number:");
            scanf("%[^\n]",temp_mobile);
            if(!validate_mobile(temp_mobile,addressbook))//validating
            goto mobile_label;
            printf(GREEN"Mobile Number is edited successfully!\n"RESET);
            //copying data
            strcpy(addressbook->contact_details[res].Mobile_number,temp_mobile);
            //displaying the edited data
            printf(YELLOW"╔══════════════════════════════════════════════════════════════════════════════╗\n"RESET);

             printf(YELLOW"║ %-20s │ %-15s │ %-25s           ║\n"RESET,
             addressbook->contact_details[res].Name,
             addressbook->contact_details[res].Mobile_number,
             addressbook->contact_details[res].Mail_ID);

            printf(YELLOW"╚══════════════════════════════════════════════════════════════════════════════╝\n"RESET);
            break;
            case 3:
            
            email_label://editing email
            getchar();
            printf("Enter the new email id:");
            scanf("%[^\n]",temp_email);
            if(!validate_email(temp_email,addressbook))//validating
            goto email_label;
            strcpy(addressbook->contact_details[res].Mail_ID,temp_email);//copying
            //displaying
            printf(YELLOW"╔══════════════════════════════════════════════════════════════════════════════╗\n"RESET);

             printf(YELLOW"║ %-20s │ %-15s │ %-25s           ║\n"RESET,
             addressbook->contact_details[res].Name,
             addressbook->contact_details[res].Mobile_number,
             addressbook->contact_details[res].Mail_ID);

            printf(YELLOW"╚══════════════════════════════════════════════════════════════════════════════╝\n"RESET);
            break;
            case 4://editing all the contact details one by one
             name1_label:
             getchar();
             printf("Enter the new name:");
             scanf("%[^\n]",temp_name);
             if(!validate_name(temp_name))
             goto name1_label;
             printf(GREEN"Name is edited successfully!\n"RESET);
             strcpy(addressbook->contact_details[res].Name,temp_name);
             
            mobile1_label:
            getchar();
            printf("Enter the new mobile Number:");
            scanf("%[^\n]",temp_mobile);
            if(!validate_mobile(temp_mobile,addressbook))
            goto mobile1_label;
            printf(GREEN"Mobile Number is edited successfully!\n"RESET);
            strcpy(addressbook->contact_details[res].Mobile_number,temp_mobile);

            email1_label:
            getchar();
            printf("Enter the new email id:");
            scanf("%[^\n]",temp_email);
            if(!validate_email(temp_email,addressbook))
           goto email1_label;
 
            printf(GREEN"Email ID is edited successfully!\n"RESET);
            strcpy(addressbook->contact_details[res].Mail_ID,temp_email);//copying

            printf(GREEN"Contact edited successfully!\n");
            //displaying
            printf(YELLOW"╔══════════════════════════════════════════════════════════════════════════════╗\n"RESET);

             printf(YELLOW"║ %-20s │ %-15s │ %-25s           ║\n"RESET,
             addressbook->contact_details[res].Name,
             addressbook->contact_details[res].Mobile_number,
             addressbook->contact_details[res].Mail_ID);

            printf(YELLOW"╚══════════════════════════════════════════════════════════════════════════════╝\n"RESET);
            break;
            default:
            printf(RED"Invalid input!Enter a valid option!"RESET);
            break;
        }
    }

   }
}

int delete_contact(AddressBook *addressbook)//deleting contact details
{
    int i=1;
   int res,choice;
   while(i)
   {
    printf("Delete Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : "); /* Providing menu */
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:
        res=search_name(addressbook);
        break;
        case 2:
        res=search_mobile(addressbook);
        break;
        case 3:
        res=search_email(addressbook);
        break;
        case 4:
        return 0;
        default:
        printf("Invalid input!Please enter a valid option!");
        break;
    }
    if(res==-1)//checking with the returned index from search function
    continue;
    else{
        int opt3;
        printf("Do you really want to delete the contact?(1-yes/0-no)");
        scanf("%d",&opt3);
        if(opt3)
        {
            for(int i=res;i<addressbook->contact_count-1;i++)
            {
                addressbook->contact_details[i]=addressbook->contact_details[i+1];//deleting selected contact
                
            }
            addressbook->contact_count--;//decrementing count
            printf(RED"Contact deleted successfully!\n"RESET);
        }
    }


    return 0;
}
}
int save_contacts(AddressBook *addressbook)//saving contact details to file
{
    sort_contacts(addressbook);
    FILE*fp=fopen("contacts.csv","w");//opening file in write mode
    if(fp==NULL)//checking if file is found or not
    {
        printf("File not found!\n");
    }
    else{//if file is found
    fprintf(fp,"#%d\n",addressbook->contact_count);//displaying count
    for(int i=0;i<addressbook->contact_count;i++)//displaying contact details
    {
    fprintf(fp,"%s,%s,%s\n",addressbook->contact_details[i].Name,addressbook->contact_details[i].Mobile_number,addressbook->contact_details[i].Mail_ID);
    }
}
    fclose(fp);//closing file
    return 0;
}

