#include<stdio.h>
#include"contact.h"
#include<string.h>
#include<ctype.h>

int validate_name(char* temp_name)//validating name
{
    if(strlen(temp_name)==0)//checking whether name is empty
    {
        printf(RED"Invalid name!Name cannot be empty!Try again.\n"RESET);
        return 0;
    }
    
    for(int i=0;temp_name[i]!='\0';i++)
    {
        if(!isalpha(temp_name[i])&& temp_name[i]!=' ') //checking whether name contains alphabets only
        {
            printf(RED"Invalid name!Name should contain only alphabets and spaces.\n"RESET);
            return 0;
        }
        if(!isupper(temp_name[0]))//checking whether first letter is uppercase
        {
            printf(RED"Invalid name!Name should start with uppercase!Try again.\n"RESET);
            return 0;
        }
        
    }
    if(strlen(temp_name)<4)//checking length of name
    {
           printf(RED"Invalid name!Name should be atleast 4 characters!Try again.\n"RESET);
           return 0;

    }


    return 1;        
}

 int validate_mobile(char* temp_mobile,AddressBook* addressbook)//validating mobile number
 { 
     if(temp_mobile[0]=='\0')//checking mobile number is empty or not
    {
        printf(RED"Invalid input!Mobile number cannot be empty!Try again.\n"RESET);
    }
    if(strlen(temp_mobile)!=10)//checking no of digits of mobile number
    {
        printf(RED"Invalid input!Mobile number should contain 10 digits!Try again.\n"RESET);
        return 0;
    }
    if(!(temp_mobile[0]<='9'&&temp_mobile[0]>='6'))//checking whether mobile number contains only digits 
    {
        printf(RED"Invalid input!Mobile number should start with digits between 6 and 9!Try again.\n"RESET);
        return 0;
    }
    for(int i=0;temp_mobile[i]!='\0';i++)
    {
    if(!(temp_mobile[i]<='9'&&temp_mobile[i]>='0'))//checking the first digit in range of 6 and 9
    {
        printf(RED"Invalid input!Mobile number should contain only numbers!Try again.\n"RESET);
        return 0;
    }
    for(int i=0;i<addressbook->contact_count;i++)
    {
        if(strcmp(temp_mobile,addressbook->contact_details[i].Mobile_number)==0)//checking mobile number is unique or not
        {
            printf(RED"Mobile number should be unique!Try again.\n"RESET);
            return 0;
        }
    }
    } 
    return 1; 
 }   



int validate_email(char* temp_email,AddressBook* addressbook)//validating email id

{
   int atcount=0,dotcount=0,atpos,dotpos;int count=0;int afterdot=0;int alpha=0;int dotafter=0;
   for(int i=0;temp_email[i]!='\0';i++)
   {
    if(temp_email[i]=='@')//checking count of @ character
    {
        atcount++;
        atpos=i;
    }
    if(temp_email[i]=='.')//checking count of . character
    {
        dotcount++;
        dotpos=i;
    }
   }
   
   
   if(atcount!=1)
   {
    printf(RED"Invalid input!Email ID should contain only one @ character!Try again.\n"RESET);
    return 0;
   }
    
   if(dotcount==0 || dotpos<atpos)
   {
    printf(RED"Invalid input!Email ID should contain one '.' character after @ character!Try again.\n"RESET);
    return 0;
   }
   char*dot=strstr(temp_email,".");
   char*at=strstr(temp_email,"@");
    int diff = dot - at;
    
    if(diff <=1)//checking validity of domain name
    
    {
        printf(RED"Invalid input!Email ID should contain a valid domain and there must be atleast 2 characters after '.' character!Try again.\n"RESET);
        return 0;
    }
    if(at - temp_email <4 || at - temp_email > 16)
    {
        printf(RED"Invalid Input!Email ID should countain atleast 4 and atmost 16 characters!Try again.\n"RESET);
        return 0;
    }
    
    for(int i=0;temp_email[i]!='\0';i++)//checking first letter of email
    {
        if(!isalnum(temp_email[0]))
        {
            printf(RED"Invalid input!Email ID should start with only alphabets or numbers!Try again.\n"RESET);
            return 0;
            
        }
    
       
        if(temp_email[i]<='Z' && temp_email[i]>='A')//checking the case of letters in email id
        {
            printf(RED"Invalid input!Email ID should be in lower case!Try again.\n"RESET);
            return 0;
        }
        if(temp_email[i]==' ')//checking if email id contain spaces
        {
            printf(RED"Email ID should not contain spaces!Try again.\n"RESET);
            return 0;
        }
        //checking email contains only alphabets ,numbers and some special characters
        if(!(isalnum(temp_email[i])||temp_email[i]=='.'||temp_email[i]=='@'||temp_email[i]=='-'||temp_email[i]=='_'))
        {
            printf(RED"Email ID should only contain alphabets,numbers and special characters - '@','.','-','_'\n"RESET);
            return 0;
        }
    }
    for(int i=0;i<atpos;i++)//checking alphabets before @ character
    {
    if(temp_email[i]>='a'&&temp_email[i]<='z')
    {
      count++;
      
    }
    }
    if(count ==0)
    {
        printf(RED"Invalid input!Email ID should contain atleast one alphabet character before @ character!Try again.\n"RESET) ;
        return 0;
    }
     

    
    for(int i=0;i<addressbook->contact_count;i++)//checking if email id is unique
    {
        if(strcmp(temp_email,addressbook->contact_details[i].Mail_ID)==0)
        {
            printf(RED"Email ID should be unique!Try again.\n"RESET);
            return 0;
        }
    }
    for(int i=dotpos+1;temp_email[i]!='\0';i++)//checking for alphabets after . character
    {
        dotafter++;
        if(temp_email[i]<='z'&&temp_email[i]>='a')
        {
        afterdot++;
        }
        if(!isalpha(temp_email[i]))
        {
            printf(RED"Invalid input!Email ID should contain only alphabets after '.' character!Try again.\n"RESET);
            return 0;
        }
    }
    if(dotafter<2)//checking number of characters after . character
    {
        printf(RED"Invalid input!There must be atleast 2 characters after '.' character!Try again\n"RESET);
        return 0; 
    }
    if(afterdot==0)
    {
        printf(RED"Invalid input!There must be alphabet characters after '.' character!Try again\n"RESET);
        return 0;
    }

        

    
        return 1;
}

        


    