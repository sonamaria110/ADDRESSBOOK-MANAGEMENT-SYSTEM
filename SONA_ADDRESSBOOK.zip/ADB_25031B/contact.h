#ifndef CONTACT_H
#define CONTACT_H

#define YELLOW "\033[1;33m"
#define BOLD   "\033[1m"
#define RED "\033[1;31m"
#define GREEN "\033[1;32m"
#define BLUE "\033[1.34m"
#define RESET "\033[0m"

typedef struct Contact_data
{
    char Name[32];
    char Mobile_number[11];
    char Mail_ID[35];
} Contacts;

typedef struct AddressBook_Data
{
    Contacts contact_details[100];
    int contact_count;
} AddressBook;

/* Function declarations */
// void init_intitalization(AddressBook *);
int create_contact(AddressBook *);
void list_contacts(AddressBook *);
int search_contacts(AddressBook *);
int edit_contact(AddressBook *);
int delete_contact(AddressBook *);
int save_contacts(AddressBook *);
int load_contacts(AddressBook *);

#endif // CONTACT_H
       // CONTACT_H