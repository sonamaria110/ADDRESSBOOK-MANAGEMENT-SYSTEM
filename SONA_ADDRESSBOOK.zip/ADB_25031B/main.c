/*
-----------------------------------------------------------------------------------
  NAME:SONAMARIA SABU K
  DATE:8 DEC 
  PROJECT NAME:ADDRESSBOOK SYSTEM
  DESCRIPTION:This project implements the core functionalities of the Contact Management
   System. It includes features to create, list, search, edit, delete and
   save contacts. Each contact contains Name, Phone Number, and Email ID.
 
   The following functions are implemented:
       - create_contact()     : Adds new contacts to the address book
       - list_contacts()      : Displays all saved contacts
       - search_contacts()    : Searches contacts using name / number / email
       - edit_contact()       : Modifies an existing contact's details
       - delete_contact()     : Removes a contact from the list
       - save_contacts()      : Saves the contact list to a CSV file
       - load_file_data()     : Loads the file data into the structure variable*/

#include <stdio.h>
#include "contact.h"

/* Structure declaration */

int main()
{
    /* Variable and structre defintion */
    int option;
    AddressBook addressbook;
    addressbook.contact_count = 0;
    load_contacts(&addressbook);
    // init_intitalization(&addressbook);

    while (1)
    {
        printf("\033[1;35m"); // Bold Magenta
printf("╭──────────────────────────────────────────────────────────────╮\n");
printf("│                      \033[1mADDRESS BOOK SYSTEM\033[0m\033[1;35m                     │\n");
printf("╰──────────────────────────────────────────────────────────────╯\n");
printf("\033[0m");

        printf("\n");
printf("┌───────────────────────────────────┐\n");
printf("        📒 ADDRESS BOOK MENU        \n");
printf("├───────────────────────────────────┤\n");
printf("│  1. Add Contact                   │\n");
printf("│  2. Search Contact                │\n");
printf("│  3. Edit Contact                  │\n");
printf("│  4. Delete Contact                │\n");
printf("│  5. Display Contacts              │\n");
printf("│  6. Save Contacts                 │\n");
printf("│  7. Exit                          │\n");
printf("└───────────────────────────────────┘\n");
printf("➤ Enter the option: ");
scanf("%d",&option);


        switch (option) /* Based on choosed option */
        {
        case 1:
        {
            create_contact(&addressbook);
            break;
        }

        case 2:
        {
            //printf("Search Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4. Exit\nEnter the option : "); /* Providing menu */
            search_contacts(&addressbook);
            break;
        }
        case 3:
            

            edit_contact(&addressbook);
            break;

        case 4:
        {
           // printf("Delete Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : "); /* Providing menu */

            delete_contact(&addressbook);
            break;
        }
        case 5:
        {
            //printf("List Contacts:");
            list_contacts(&addressbook);
            break;
        }

        case 6:
            printf(GREEN"Saving contacts...\n"RESET);
            //sort_contacts(&addressbook);
            save_contacts(&addressbook);
            printf("\033[1;32m");
printf("╭──────────────────────────────────────────╮\n");
printf("│   ✔ Contact added successfully!          │\n");
printf("╰──────────────────────────────────────────╯\n");
printf("\033[0m");

            break;

        case 7:
            save_contacts(&addressbook);
            printf("INFO : Save and Exit...\n");
            return 0;

        default:
            printf("Invalid option \n");
            break;
        
    }
}
    return 0;


}



