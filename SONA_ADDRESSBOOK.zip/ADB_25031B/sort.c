#include<stdio.h>
#include"contact.h"
#include<string.h>
#include<ctype.h>
void sort_contacts(AddressBook* addressbook);
void lowercase(char str[])
{
    for(int i=0;str[i]!='\0';i++)
    {
        str[i]=tolower(str[i]);

    }
}


void sort_contacts(AddressBook* addressbook)
{
 char temp[30],str1[30],str2[30];


    for(int i=0;i<addressbook->contact_count-1;i++)
    {
        for(int j=0;j<addressbook->contact_count-1;j++)
        {

            strcpy(str1,addressbook->contact_details[j].Name);
            strcpy(str2,addressbook->contact_details[j+1].Name);
            lowercase(str1);
            lowercase(str2);
            if(strcmp(str1,str2)>0)
            {
                strcpy(temp,addressbook->contact_details[j].Name);
                strcpy(addressbook->contact_details[j].Name,addressbook->contact_details[j+1].Name);
                strcpy(addressbook->contact_details[j+1].Name,temp);

                strcpy(temp,addressbook->contact_details[j].Mobile_number);
                strcpy(addressbook->contact_details[j].Mobile_number,addressbook->contact_details[j+1].Mobile_number);
                strcpy(addressbook->contact_details[j+1].Mobile_number,temp);

                strcpy(temp,addressbook->contact_details[j].Mail_ID);
                strcpy(addressbook->contact_details[j].Mail_ID,addressbook->contact_details[j+1].Mail_ID);
                strcpy(addressbook->contact_details[j+1].Mail_ID,temp);
            }
            
        }
    }

    
}